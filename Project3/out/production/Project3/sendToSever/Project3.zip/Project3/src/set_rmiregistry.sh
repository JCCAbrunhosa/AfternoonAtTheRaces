rmiregistry -J-Djava.rmi.server.codebase="http://193.136.172.20/sd0307/Public/classes/"\
            -J-Djava.rmi.server.useCodebaseOnly=true $1
