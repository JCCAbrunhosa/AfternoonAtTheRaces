java -Djava.rmi.server.codebase="http://193.136.172.20/sd0307/Public/classes/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     clientSide.ClientMain
