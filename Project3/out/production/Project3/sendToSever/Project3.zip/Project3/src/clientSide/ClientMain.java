package clientSide;

import extras.PortsCom;
import interfaces.*;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClientMain {

    public static StableInterface stableInterface;
    public static RepositoryInterface repositoryInterface;
    public static RacingTrackInterface racingTrackInterface;
    public static PaddockInterface paddockInterface;
    public static ControlCenterInterface controlCenterInterface;
    public static BettingCenterInterface bettingCenterInterface;
    public static Registry registry;

    public static int rmiPort;
    public static String rmiName;

    //Initiate variables
    public static int nrHorses = 4;
    public static int nrSpectators = 4;
    public static Horse horse = null;
    public static Spectator spectator = null;
    public static ArrayList<Spectator> listSpectator = new ArrayList<>();
    public static ArrayList<Horse> listHorse = new ArrayList<>();
    public static Random rand = new Random();
    public static double winningChance = 0;
    public static double totalChance = 1.0;


    public static void main(String[] args) throws RemoteException, NotBoundException {

        //Get registry
        rmiPort=PortsCom.rmiPort;
        rmiName=PortsCom.rmiName;

        registry = LocateRegistry.getRegistry(rmiName,rmiPort);
        stableInterface=(StableInterface) registry.lookup("Stable");
        repositoryInterface=(RepositoryInterface) registry.lookup("Repository");
        racingTrackInterface=(RacingTrackInterface) registry.lookup("RacingTrack");
        paddockInterface=(PaddockInterface) registry.lookup("Paddock");
        controlCenterInterface=(ControlCenterInterface) registry.lookup("ControlCenter");
        bettingCenterInterface=(BettingCenterInterface) registry.lookup("BettingCenter");

        startClients();


    }


    public static void startClients() throws RemoteException {
        try {
            //Then we create the threads
            Broker broker = new Broker(racingTrackInterface, stableInterface, bettingCenterInterface, controlCenterInterface, paddockInterface, repositoryInterface);
            broker.getPriority();
            broker.start();

            for (int i = 1; i <= nrHorses; i++) {
                rand = new Random();
                winningChance = 0 + (rand.nextDouble() * (totalChance - 0));
                totalChance = totalChance - winningChance;
                if (i == nrHorses)
                    winningChance = totalChance;
                System.out.println(i + " has winning change of " + winningChance);

                int maxDistance = 1 + rand.nextInt((10 - 1) + 1);//Distance varies between 1 and 10
                horse = new Horse(i, 0, new Random().nextInt(maxDistance), Math.abs(maxDistance), winningChance, stableInterface, paddockInterface, racingTrackInterface, repositoryInterface);
                listHorse.add(horse);
                horse.start();
            }

            for (int j = 1; j <= nrSpectators; j++) {
                spectator = new Spectator(j, 400, paddockInterface, bettingCenterInterface, controlCenterInterface, repositoryInterface);
                listSpectator.add(spectator);
                spectator.start();
            }
        }catch (Exception e){
            Logger.getLogger(ClientMain.class.getName()).log(Level.SEVERE, null, e);
        }
    }
}
