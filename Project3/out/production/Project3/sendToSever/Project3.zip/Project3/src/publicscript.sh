cd ~/Public/
mkdir classes
mkdir classes/interfaces
mkdir classes/clientSide
cp ../Project3/src/interfaces/*.class classes/interfaces
cp ../Project3/src/clientSide/*.class classes/clientSide
