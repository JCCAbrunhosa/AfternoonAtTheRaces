echo "deleting..."
rm extras/*.class interfaces/*.class registry/*.class clientSide/*.class serverSide/*.class Main/*.class
echo "Done!"
