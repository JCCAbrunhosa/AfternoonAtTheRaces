java -Djava.rmi.server.codebase="file://home/tatiana/Documents/SD/sdraces_p03g7/Project3/src/dir_serverSide\"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     serverSide.ServerMain
