/**
 * Directory Server Side
 */
package dir_serverSide;