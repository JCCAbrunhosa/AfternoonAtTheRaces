/**
 * Directory Client Side
 */
package dir_clientSide;