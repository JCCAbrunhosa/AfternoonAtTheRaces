java -Djava.rmi.server.codebase="file://home/tatiana/Documents/SD/sdraces_p03g7/Project3/src/dir_clientSide\"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     clientSide.ClientMain
