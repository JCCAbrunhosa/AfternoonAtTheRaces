/**
 * Directory registry
 */
package dir_registry;