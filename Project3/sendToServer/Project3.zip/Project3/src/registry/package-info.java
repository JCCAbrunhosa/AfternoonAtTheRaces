/**
 * Register remote objects in the local registry service: RegisterRemoteObject and ServerRegisterRemoteObject
 */
package registry;