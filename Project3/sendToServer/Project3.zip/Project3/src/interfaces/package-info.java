/**
 * All interfaces
 * */
package interfaces;